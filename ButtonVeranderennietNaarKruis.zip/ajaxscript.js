console.log("ajax")

var search = document.querySelector("#search")
var zoekButton = document.querySelector("button:nth-of-type(1)");
var menu = document.querySelector("#menu")
var hamburgerButton = document.querySelector("button:nth-of-type(2)");
var languageButton = document.querySelector("header nav button");


// function toggleMenu() {
//     var openzoekButton = document.querySelector ("form")
//     openzoekButton.classList.toggle("ga");
//     search.src = "AjaxContent/ic-close.svg";
// }

hamburgerButton.addEventListener("click", toggleMenu);
var deNav = document.querySelector("header nav");



function toggleMenu() {
	
	deNav.classList.toggle("open");
    hamburgerButton.classList.toggle("open");
   
    openzoekButton.classList.remove("ga");
    zoekButton.classList.remove("ga");
}


zoekButton.addEventListener("click", toggleSearch);
var openzoekButton = document.querySelector ("form")

function toggleSearch() {
    
    openzoekButton.classList.toggle("ga");
    zoekButton.classList.toggle("ga");

    deNav.classList.remove("open");
    hamburgerButton.classList.remove("open");
}









languageButton.addEventListener("click", toggle);
var talenButton = document.querySelector ("header nav ul:nth-of-type(3)")

function toggle() {
    
    talenButton.classList.toggle("laatzien");

}






// var menu = document.querySelector("#menu")
// var hamburgerButton = document.querySelector("#hamburger");

// hamburgerButton.addEventListener("click", toggleMenu);

// function toggleMenu() {
// 	var openButton = document.querySelector("header nav");
// 	openButton.classList.toggle("open");
//     menu.src = "AjaxContent/ic-close.svg";

// }